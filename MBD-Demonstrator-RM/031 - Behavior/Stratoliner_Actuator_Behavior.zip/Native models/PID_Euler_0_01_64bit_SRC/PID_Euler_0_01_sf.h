/*
* Generated S-function Target for model PID_Euler_0_01. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri May 18 15:43:36 2018
*/

#ifndef RTWSFCN_PID_Euler_0_01_sf_H
#define RTWSFCN_PID_Euler_0_01_sf_H

#include "PID_Euler_0_01_sfcn_rtw/PID_Euler_0_01_sf.h"
  #include "PID_Euler_0_01_sfcn_rtw/PID_Euler_0_01_sf_private.h"

#endif
